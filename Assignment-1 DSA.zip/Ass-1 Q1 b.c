#include<stdio.h>
int main()
{
    int i,j,n;
    for(i=1;i<=n;i*3)
    {
       for(j=i;i<=n;j++)
       {
          printf("hello");
       }

    }
    return 0;
}