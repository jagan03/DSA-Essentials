#include<stdio.h>
int main()
{
    int i,j,n;
    for(i=1;i<=n;i++)
    {

        printf("HI \n");
    }
    return 0;
}